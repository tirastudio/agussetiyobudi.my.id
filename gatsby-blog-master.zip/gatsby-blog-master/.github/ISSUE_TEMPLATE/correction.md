---
name: Correction
about: Anything not correct, did I make a typo? Mention it here.
title: ''
labels: Correction
assignees: ''

---

**Page**:

https://dimitr.im/link-to-the-blogpost

**Description**:

Describe what exactly is wrong. For example, you made a typo in the first paragraph about getting started. You should use "it's" in stead of "its".
