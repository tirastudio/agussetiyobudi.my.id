---
name: Blog idea
about: Do you have an interesting idea for a new blogpost? Share it here.
title: ''
labels: Blogpost
assignees: ''

---

**Title**:

Describe what the potential title could be. Keep it short. For example "Loading initial data with Spring Data", "Using Gatsby with WordPress", ... .

**Description**:

Describe what the blogpost should be about. What technologies should it cover.

**Links**:

- [Interesting documentation](https://link-to-interesting-documentation)
