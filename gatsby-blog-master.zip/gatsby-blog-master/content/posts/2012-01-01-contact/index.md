---
title: "Contact"
date: "2012-01-01"
categories: ["Pages"]
---

I’m open for questions, suggestions, ideas or other feedback you want to share.
To contact me, you can open an issue on my [GitHub repository](https://github.com/g00glen00b/gatsby-blog/issues) (preferred).

Alternatively, you can find me on [Twitter](https://twitter.com/g00glen00b). 
Either mention me in a new tweet, or send me a DM if you prefer to discuss things in private.

If you’re wondering why I’m not sharing an e-mail address, that’s because I learned from that. 
I initially started out with a public e-mail address, but 99% of the conversations were spam.
Then I moved on to a comment section, but yet again, it was abused by spam.

After that, I decided to move my comments to Disqus. 
Things were working out smoothly, but then they decided that your privacy is worth nothing, and loaded ads and various trackers.

Finally, I used some contact form on my blog, but guess what, that also got abused by spammers.

I could install some fancy captchas, but after giving it some thoughts, I decided I wouldn’t be. 
Considering that most people trying to contact me are developers, and many developers have a GitHub profile, using GitHub issues seem to be the best solution… for now. 

