---
name: Design idea
about: Is accessibility, web design or anything else related to the UI up for improvement?
  Share it!
title: ''
labels: Design
assignees: ''

---

**Description**:

Describe what exacly could be improved. For example, this text on the homepage is not very readable.
